# Imports
from django.urls import path
from atomicloops.views import UsersView
from rest_framework.routers import DefaultRouter
from atomicloops.login_view import LoginView, RefreshTokenView
from atomicloops.logout_views import LogoutView, LogoutAllView
from atomicloops.reset_password_views import (
    reset_password_validate_token,
    reset_password_confirm,
    reset_password_request_token
)

router = DefaultRouter()
router.register('users', UsersView, basename='users')

urlpatterns = [
    path('login/', LoginView.as_view(), name='token_obtain_pair'),
    path('login/refresh/', RefreshTokenView.as_view(), name='token_refresh'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('logout-all/', LogoutAllView.as_view(), name='logout-all'),
    path("reset-password-validate-token/", reset_password_validate_token, name="reset-password-validate"),
    path("reset-password-confirm/", reset_password_confirm, name="reset-password-confirm"),
    path("reset-password-request/", reset_password_request_token, name="reset-password-request"),
]

urlpatterns += router.urls
