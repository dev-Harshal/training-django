from datetime import datetime


def write_custom_time(str_date):
    standard_format = '%d-%m-%YT%H:%M:%S'
    formatted_time = datetime.strptime(str_date, standard_format)
    return formatted_time


def get_current_time():
    return write_custom_time(datetime.strftime(datetime.now(), '%d-%m-%YT%H:%M:%S'))
