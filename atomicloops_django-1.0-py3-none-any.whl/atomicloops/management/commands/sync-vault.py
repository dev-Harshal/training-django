from django.conf import settings
import boto3
import datetime
import os
from django.core.management.base import BaseCommand

s3 = boto3.client("s3", region_name=settings.REGION, aws_access_key_id=settings.AWS_KEY_ID, aws_secret_access_key=settings.AWS_SECRET_KEY)


# validate-setup
class Command(BaseCommand):
    help = 'run this command in order to sync the vault file'

    def handle(self, *args, **kwargs):
        vault_path = os.path.join(settings.BASE_DIR, "src", "vault.py")
        time = str(datetime.datetime.now()).split(".")[0].replace(' ', '-')
        s3.upload_file(
            vault_path,
            settings.S3_BUCKET,
            f"{settings.PROJECT_NAME}/vault_{time}.py",
            ExtraArgs={'ACL': 'public-read'})
        url = os.path.join(settings.AWS_URL, f"{settings.PROJECT_NAME}/vault_{time}.py")
        print("File uploaded successfully")
        print("This is the new vault url :")
        print(url)
        print("Please update this url in the README in the Latest Section")
