

# Reset Password Link
def reset_password_message(token):
    return f"""Your reset password token is {token}"""


# Update Password Template
def update_password_message():
    return """Password has been updated successfully"""


# Register Message
def register_message():
    return """Successfully registered."""


# TODO Update this function as per project requirements
def filter_users_query(model, self):
    if self.request.user.user_level == 0:
        return model.objects.all()
    if self.request.user.user_level == 5:
        return model.objects.exclude(userId__user_level=0)
    return model.objects.filter(userId__user_level=0)
