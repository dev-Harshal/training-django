from .models import Users
from django.contrib import admin
from import_export.admin import ImportExportModelAdmin


@admin.register(Users)
class UsersAdmin(ImportExportModelAdmin):
    list_display = (
        'id',
        'password',
        'last_login',
        'first_name',
        'last_name',
        'email',
        'date_joined',
        'phone_number',
        'user_level',
        'is_active',
        'is_staff',
        'is_superuser',
    )
    list_filter = (
        'last_login',
        'date_joined',
        'is_active',
        'is_staff',
        'is_superuser',
    )
    search_fields = (
        "first_name",
        "last_name",
        "email",
    )
    raw_id_fields = ('groups', 'user_permissions')
