# Import
from rest_framework.views import Response
from atomicloops.serializers import (
    GetUsersSerializer, ListUsersSerializer, SelfUsersSerializer,
)
from atomicloops.models import Users
from rest_framework_simplejwt.authentication import JWTAuthentication
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from rest_framework import status
from atomicloops.permissions import UsersPermission
from rest_framework_simplejwt.tokens import RefreshToken
from atomicloops.pagination import AtomicloopsPagination
from atomicloops.signals import send_registration_email
from atomicloops.renderers import AtomicJsonRenderer
from rest_framework_simplejwt.token_blacklist.models import BlacklistedToken, OutstandingToken
import sys
from .filters import UsersFilter
from .viewsets import AtomicViewSet


class UsersView(AtomicViewSet):
    queryset = Users.objects.all()
    pagination_class = AtomicloopsPagination
    authentication_classes = [JWTAuthentication, ]
    permission_classes = [UsersPermission]
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    renderer_classes = [AtomicJsonRenderer]
    search_fields = ['first_name', 'last_name', 'email',]
    filterset_fields = ["user_level"]
    filterset_class = UsersFilter

    def get_serializer_class(self, *args, **kwargs):
        if self.action == 'list':
            return ListUsersSerializer
        if self.action == 'create':
            return SelfUsersSerializer
        if self.action == 'retrieve':
            try:
                if self.get_object().email == self.request.user.email:
                    return SelfUsersSerializer
            except:
                _ = sys.exc_info()[0]
                return GetUsersSerializer
        return GetUsersSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            token = RefreshToken.for_user(user)
            data = {
                'refresh': str(token),
                'access': str(token.access_token),
            }
            send_registration_email.send(sender=self.__class__, instance=self)

            return Response(data, status.HTTP_201_CREATED)
        return Response({"message": serializer.errors}, status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.is_active = False
        instance.save()
        tokens = OutstandingToken.objects.filter(user_id=instance.id)
        for token in tokens:
            t, _ = BlacklistedToken.objects.get_or_create(token=token)
        return Response(status=status.HTTP_204_NO_CONTENT)
