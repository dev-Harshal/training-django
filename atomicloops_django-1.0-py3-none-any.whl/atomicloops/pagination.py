from rest_framework import pagination


class AtomicloopsPagination(pagination.LimitOffsetPagination):
    default_limit = 10
