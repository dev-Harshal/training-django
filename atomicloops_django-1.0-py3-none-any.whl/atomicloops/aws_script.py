from django.conf import settings
import uuid
import boto3
import os

s3 = boto3.client("s3", region_name=settings.REGION, aws_access_key_id=settings.AWS_KEY_ID, aws_secret_access_key=settings.AWS_SECRET_KEY)


def upload_image(file, folder=None):
    image_id = str(uuid.uuid4())
    file_bytes = file.open()
    if folder is not None and folder != "":
        aws_path = os.path.join(settings.PROJECT_NAME, folder, "images", f"{image_id}.jpg")
    else:
        aws_path = os.path.join(settings.PROJECT_NAME, "images", f"{image_id}.jpg")
    try:
        s3.upload_fileobj(
            file_bytes,
            settings.S3_BUCKET,
            aws_path,
            ExtraArgs={'ACL': 'public-read'})
        url = f"{settings.AWS_URL}/{aws_path}"
        return url
    except Exception:
        return None
