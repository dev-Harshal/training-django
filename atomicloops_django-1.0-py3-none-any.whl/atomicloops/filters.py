from django_filters import FilterSet
from .models import Users


class UsersFilter(FilterSet):
    class Meta:
        model = Users
        fields = {
            "first_name": ['in', 'exact', 'icontains'],
            "last_name": ['in', 'exact', 'icontains'],
            "email": ['in', 'exact', 'icontains'],
            "is_active": ['exact', 'in'],
            "user_level": ['in', 'exact']
        }
