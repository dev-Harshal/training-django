from rest_framework import serializers
from .models import Users


class SelfUsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        exclude = ("is_staff", "is_superuser", "groups", "user_permissions")

    def create(self, validated_data):
        user = Users.objects.create(
            email=validated_data['email'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
            phone_number=validated_data['phone_number'],
        )
        user.set_password(validated_data['password'])
        user.save()
        return user


class GetUsersSerializer(serializers.ModelSerializer):
    class Meta:
        model = Users
        exclude = (
            "password", "user_level", "is_active", "is_staff",
            "is_superuser", "createdAt", "updatedAt", "groups", "user_permissions"
        )


class ListUsersSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Users
        fields = ("id", "first_name", "last_name", "email", "url")
